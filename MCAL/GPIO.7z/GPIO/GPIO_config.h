/*****************************************************************/
/* Author  : El-Neshwy                                           */
/* Layer   : MCAL                                                */
/* SWC     : GPIO                                                */
/* Version : 1.0                                                 */
/* Date    : 09 Oct 2023                                         */
/*****************************************************************/
#ifndef GPIO_CONFIG_H_
#define GPIO_CONFIG_H_

#define GPIO_PIN_NUM			35

#endif